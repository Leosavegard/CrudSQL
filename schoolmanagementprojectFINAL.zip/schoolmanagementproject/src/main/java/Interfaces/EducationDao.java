package Interfaces;

import Entity.Education;

public interface EducationDao {

    Education createEducation();

    void addEducation(Education education);

    void addEducationToExistingStudent(Education education);

    void removeEducation();

    void updateEducationName();

    void updateEducationLength();

    void showEducation();

    void showAllEducations();

}
