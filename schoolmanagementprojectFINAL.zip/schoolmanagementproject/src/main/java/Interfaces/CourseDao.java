package Interfaces;

import Entity.Course;

public interface CourseDao {

    Course createCourse();

    void addCourse(Course course);

    void addCourseToExistningEducation(Course course);

    void removeCourse();

    void updateCourseName();

    void updateCoursePoints();

    void showCourse();

    void showAllCourses();

    void connectCourseWithEducation();
}



