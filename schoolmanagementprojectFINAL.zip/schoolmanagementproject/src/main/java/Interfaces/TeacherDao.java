package Interfaces;

import Entity.Teacher;

public interface TeacherDao {
    Teacher createTeacher();

    void addTeacher(Teacher teacher);

    void addTeacherToExistingCourse(Teacher teacher);

    void removeTeacher();

    void updateTeacherName();

    void showTeacher();

    void showAllTeachers();

    void connectTeacherWithCourse();

}
