package Interfaces;

import Entity.Student;

public interface StudentDao {

    Student createStudent();

    void addStudent(Student student);

    void addStudentToExistingEducation(Student student);

    void removeStudent();

    void updateStudentName();

    void updateStudentAge();

    void showStudent();

    void showAllStudents();

    void connectStudentWithEducation();

}
