package MenuSwitches;

import Management.Utility;
import UI.TeacherUI;

import static Main.MainProgram.*;

public class TeacherSwitch {


    public void teacherMainSwitch() {

        boolean teacherMenuLoop = true;

        while (teacherMenuLoop) {

            TeacherUI.teacherMainMenu();

            int choice = Utility.readIntInput();

            switch (choice) {

                case 1:
                    teacherAddSwitch();
                    break;

                case 2:
                    tmgmt.removeTeacher();
                    break;

                case 3:
                    tmgmt.updateTeacherName();
                    break;

                case 4:
                    showTeacherSwitch();
                    break;

                case 0:
                    teacherMenuLoop = false;
                    break;

                default:
                    Utility.noSuchOptionText();

            }
        }
    }

    private void showTeacherSwitch() {

        TeacherUI.showTeacherMenu();


        int choice = Utility.readIntInput();

        switch (choice) {

            case 1:
                tmgmt.showTeacher();
                break;

            case 2:
                tmgmt.showAllTeachers();
                break;

            default:
                Utility.noSuchOptionText();

        }
    }


    public void teacherAddSwitch(){

    TeacherUI.addTeacherMenu();


    int choice = Utility.readIntInput();

    switch (choice) {

        case 1:
            tmgmt.addTeacher(tmgmt.createTeacher());
            break;

        case 2:
            tmgmt.addTeacherToExistingCourse(tmgmt.createTeacher());
            break;

        case 3:
            tmgmt.connectTeacherWithCourse();
            break;

        default:
            Utility.noSuchOptionText();
    }
}

}
