package MenuSwitches;


import Management.Utility;
import UI.EducationUI;


import static Main.MainProgram.*;

public class EducationSwitch {


    public void educationSwitch() {

        boolean educationMenuLoop = true;

        while (educationMenuLoop) {

            EducationUI.educationMainMenu();

            int choice = Utility.readIntInput();

            switch (choice) {
                case 1:
                    addEducationSwitch();
                    break;

                case 2:
                    removeEducationSwitch();
                    break;

                case 3:
                    educationUpdateSwitch();
                    break;

                case 4:
                    educationShowSwitch();
                    break;

                case 0:
                    educationMenuLoop = false;
                    break;

                default:
                    Utility.noSuchOptionText();


            }
        }
    }

    private void removeEducationSwitch() {

        EducationUI.educationRemoveMenu();

        int choice = Utility.readIntInput();

        switch (choice) {

            case 1:
                emgmt.removeEducation();
                break;

            case 2:
                emgmt.removeEducationFromStudent();

            default:
                Utility.noSuchOptionText();
        }



    }

    private void educationShowSwitch() {
        EducationUI.showEducationMenu();

        int choice = Utility.readIntInput();

        switch (choice) {

            case 1:
                emgmt.showEducation();
                break;
            case 2:
                emgmt.showAllEducations();
            default:
                Utility.noSuchOptionText();

        }

    }

    private void addEducationSwitch() {

        EducationUI.educationAddMenu();

        int choice = Utility.readIntInput();

        switch (choice) {
            case 1:
                emgmt.addEducation(emgmt.createEducation());
                break;
            case 2:
                emgmt.addEducationToExistingStudent(emgmt.createEducation());
                break;
            default:
                Utility.noSuchOptionText();

        }
    }

    private void educationUpdateSwitch() {

        EducationUI.educationUpdateMenu();

        int choice = Utility.readIntInput();

        switch (choice) {

            case 1:
                emgmt.updateEducationName();
                break;

            case 2:
                emgmt.updateEducationLength();
                break;

            default:
                Utility.noSuchOptionText();
        }


    }

}

