package MenuSwitches;

import Management.Utility;
import UI.MainUI;

public class MainSwitch {

    StudentSwitch sw = new StudentSwitch();
    TeacherSwitch tw = new TeacherSwitch();
    CourseSwitch cw = new CourseSwitch();
    EducationSwitch ew = new EducationSwitch();
    StatisticSwitch statw = new StatisticSwitch();


    public void runProgram() {

        boolean mainMenuLoop = true;

        while (mainMenuLoop) {

            MainUI.mainMenu();

            int choice = Utility.readIntInput();

            switch (choice) {

                case 1:
                    sw.studentSwitch();
                    break;
                case 2:
                    tw.teacherMainSwitch();
                    break;

                case 3:
                    ew.educationSwitch();
                    break;

                case 4:
                    cw.courseMainSwitch();
                    break;

                case 5:
                    statw.statisticSwitch();
                    break;

                case 0:
                    mainMenuLoop = false;
                    break;
                default:
                    Utility.noSuchOptionText();


            }

        }

    }


}


