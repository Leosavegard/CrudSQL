package MenuSwitches;

import Management.Utility;
import UI.StudentUI;

import static Main.MainProgram.*;


public class StudentSwitch {

    public void studentSwitch() {

        boolean studentMenuLoop = true;

        while (studentMenuLoop) {

            StudentUI.studentMainMenu();

            int choice = Utility.readIntInput();

            switch (choice) {
                case 1:
                    addStudentSwitch();
                    break;

                case 2:
                    studentRemoveMenu();
                    break;

                case 3:
                    studentUpdateSwitchs();
                    break;

                case 4:
                    studentShowMenu();
                    break;

                case 0:
                    studentMenuLoop = false;
                    break;

                default:
                    Utility.noSuchOptionText();


            }
        }
    }

    public void addStudentSwitch() {

        StudentUI.studentAddMenu();

        int choice = Utility.readIntInput();

        switch (choice) {

            case 1:
                smgmt.addStudent(smgmt.createStudent());
                break;

            case 2:
                smgmt.addStudentToExistingEducation(smgmt.createStudent());
                break;

            case 3:
                smgmt.connectStudentWithEducation();

            default:
                Utility.noSuchOptionText();
        }
    }

    public void studentUpdateSwitchs() {

        StudentUI.studentUpdateMenu();

        int choice = Utility.readIntInput();

        switch (choice) {

            case 1:
                smgmt.updateStudentName();
                break;

            case 2:
                smgmt.updateStudentAge();
                break;

            default:
                Utility.noSuchOptionText();
        }

    }

    public void studentShowMenu() {

        StudentUI.StudentShowMenu();

        int choice = Utility.readIntInput();

        switch (choice) {

            case 1:
                smgmt.showStudent();
                break;

            case 2:
                smgmt.showAllStudents();
                break;

            default:
                Utility.noSuchOptionText();


        }
    }

    public void studentRemoveMenu() {

        StudentUI.studentRemoveMenu();

        int choice = Utility.readIntInput();

        switch (choice) {

            case 1:
                smgmt.removeStudent();
                break;

            case 2:
                smgmt.removeStudentFromEducation();
                break;

        }


    }

}
