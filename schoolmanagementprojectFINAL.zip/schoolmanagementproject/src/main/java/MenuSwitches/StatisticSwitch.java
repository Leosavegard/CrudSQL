package MenuSwitches;
import Management.Utility;
import UI.StatisticUI;

import static Main.MainProgram.*;

public class StatisticSwitch {

    public void statisticSwitch() {

        boolean statisitcMenuLoop = true;


        while (statisitcMenuLoop) {

            StatisticUI.statisticMainMenu();

            int choice = Utility.readIntInput();

            switch (choice) {

                case 1:
                    statgmt.averageAgeStudents();
                    break;

                case 2:
                    statgmt.maxAndMinAgeStudent();
                    break;

                case 3:
                    statgmt.numberOfTeachers();
                    break;

                case 4:
                    statgmt.averageEducationLength();
                    break;

                case 5:
                    statgmt.maxAndMinEducationLength();
                    break;

                case 0:
                    statisitcMenuLoop = false;
                    break;

                default:
                    Utility.noSuchOptionText();

            }

        }
    }
}
