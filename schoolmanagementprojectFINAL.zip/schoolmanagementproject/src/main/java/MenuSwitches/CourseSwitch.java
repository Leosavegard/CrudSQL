package MenuSwitches;

import Management.Utility;
import UI.CourseUI;

import static Main.MainProgram.*;

public class CourseSwitch {

    public void courseMainSwitch() {

        boolean courseMenuLoop = true;

        while (courseMenuLoop) {

            CourseUI.courseMainMenu();

            int choice = Utility.readIntInput();

            switch (choice) {

                case 1:
                    courseAddSwtich();
                    break;

                case 2:
                    cmgmt.removeCourse();
                    break;

                case 3:
                    courseUpdateSwitch();
                    break;

                case 4:
                    courseShowSwitch();
                    break;

                case 0:
                    courseMenuLoop = false;
                    break;

                default:
                    Utility.noSuchOptionText();
            }
        }
    }

    private void courseShowSwitch() {

        CourseUI.showCourseMenu();

        int choice = Utility.readIntInput();

        switch (choice) {

            case 1:
                cmgmt.showCourse();
                break;

            case 2:
                cmgmt.showAllCourses();
                break;

            default:
                Utility.noSuchOptionText();
        }
    }

    private void courseAddSwtich() {

        CourseUI.courseAddMenu();

        int choice = Utility.readIntInput();

        switch (choice) {

            case 1:
                cmgmt.addCourse(cmgmt.createCourse());
                break;

            case 2:
                cmgmt.addCourseToExistningEducation(cmgmt.createCourse());
                break;

            case 3:
                cmgmt.connectCourseWithEducation();
                break;

            default:
                Utility.noSuchOptionText();

        }
    }

    private void courseUpdateSwitch() {

        CourseUI.courseUpdateMenu();

        int choice = Utility.readIntInput();

        switch (choice) {

            case 1:
                cmgmt.updateCourseName();
                break;
            case 2:
                cmgmt.updateCoursePoints();
                break;

            default:
                Utility.noSuchOptionText();
        }


    }
}
