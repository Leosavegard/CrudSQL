package UI;

public class StatisticUI {

    public static void statisticMainMenu(){
        System.out.println("① Average student age");
        System.out.println("② Oldest and youngest student age");
        System.out.println("③ Amount of teachers");
        System.out.println("④ Average education length");
        System.out.println("⑤ Longest and shortest education");
        System.out.println("⓿ Return");
    }


}
