package UI;

import Management.Utility;

public class EducationUI {

    public static void educationMainMenu() {

        System.out.println("① Add");
        System.out.println("② Remove");
        System.out.println("③ Update");
        System.out.println("④ Show");
        System.out.println("⓿ Return");
    }

    public static void educationAddMenu() {

        System.out.println("① Add new education");
        System.out.println("② Add education to existing student");
    }

    public static void educationUpdateMenu() {

        System.out.println("① Update education name");
        System.out.println("② Update education length");
    }

    public static void showEducationMenu(){

        System.out.println("① Find education by id");
        System.out.println("② Show All educations");
    }

    public static void showAllEducationHeader(){
        System.out.println("┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓");
        System.out.println("┃      ID          ┃     NAME      ┃      LENGTH      ┃");
        System.out.println("┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛");

    }

    public static void showAllFooter(){

        System.out.println("┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓");
        System.out.println("┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛");
    }

    public static void educationRemoveMenu() {

        System.out.println("① Remove education");
        System.out.println("② Remove Student from education");
    }
}
