package UI;

public class CourseUI {

    public static void courseMainMenu() {

        System.out.println("① Add");
        System.out.println("② Remove");
        System.out.println("③ Update");
        System.out.println("④ Show");
        System.out.println("⓿ Return");
    }

    public static void courseAddMenu() {

        System.out.println("① Add new course");
        System.out.println("② Add new course to existing education");
        System.out.println("③ Connect course with education");
    }

    public static void courseUpdateMenu() {

        System.out.println("① Update course name");
        System.out.println("② Update course points");
    }

    public static void showCourseMenu() {

        System.out.println("① Find course by id");
        System.out.println("② Show All courses");
    }

    public static void showAllCoursesHeader() {
        System.out.println("┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓");
        System.out.println("┃      ID:       ┃     NAME:     ┃     POINTS    ┃");
        System.out.println("┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛");

    }

    public static void showAllFooter() {

        System.out.println("┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓");
        System.out.println("┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛");
    }

}
