package UI;

public class StudentUI {

    public static void studentMainMenu() {

        System.out.println("① Add");
        System.out.println("② Remove");
        System.out.println("③ Update");
        System.out.println("④ Show");
        System.out.println("⓿ Return");
    }

    public static void studentAddMenu() {

        System.out.println("① Add new student.");
        System.out.println("② Add new student to existing education.");
        System.out.println("③ Connect existing student & education.");
    }

    public static void StudentShowMenu() {

        System.out.println("① Find student by id.");
        System.out.println("② Show All students.");
    }

    public static void studentUpdateMenu() {

        System.out.println("① Update student name");
        System.out.println("② Update student age");
    }

    public static void showAllStudentHeader() {
        System.out.println("┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓");
        System.out.println("┃     ID        ┃         NAME         ┃        AGE    ┃");
        System.out.println("┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛");

    }

    public static void showAllFooter() {

        System.out.println("┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓");
        System.out.println("┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛");
    }

    public static void studentRemoveMenu() {

        System.out.println("① Remove student");
        System.out.println("② Remove education from student");
    }
}

