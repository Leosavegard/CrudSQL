package UI;

public class MainUI {

    public static void mainMenu() {

        mainMenuHeader();

        System.out.println("║██████████   ① Students    █████████║");
        System.out.println("║██████████   ② Teachers    █████████║");
        System.out.println("║██████████   ③ Educations  █████████║");
        System.out.println("║██████████   ④ Courses     █████████║");
        System.out.println("║██████████   ⑤ Statistics  █████████║");
        System.out.println("║██████████   ⓿ Exit        █████████║");
        System.out.println("╚════════════════════════════════════╝");
    }

public static void mainMenuHeader(){

    System.out.println("╔═════════════════════════════════════╗");
    System.out.println("║██████████SCHOOL MANAGEMENT██████████║ ");
    System.out.println("╚═════════════════════════════════════╝ ");
}

}
