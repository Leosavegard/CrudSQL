package UI;

public class TeacherUI {

    public static void teacherMainMenu() {

        System.out.println("① Add");
        System.out.println("② Remove");
        System.out.println("③ Update");
        System.out.println("④ Show");
        System.out.println("⓿ Return");
    }

    public static void addTeacherMenu() {

        System.out.println("① Add new teacher");
        System.out.println("② Add new teacher to existing course");
        System.out.println("③ Connect teacher with course");
    }


    public static void showTeacherMenu() {

        System.out.println("① Find teacher by id");
        System.out.println("② Show All teachers");
    }
    public static void showAllTeacherHeader(){
        System.out.println("┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓");
        System.out.println("┃         ID          ┃       NAME         ┃");
        System.out.println("┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛");

    }

    public static void showAllteacherFooter(){

        System.out.println("┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓");
        System.out.println("┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛");
    }
}
