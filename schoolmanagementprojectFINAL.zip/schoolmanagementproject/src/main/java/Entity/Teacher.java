package Entity;


import Management.Utility;

import java.util.List;
import java.util.Objects;
import javax.persistence.*;


@Entity
public class Teacher {

    @Id
    @GeneratedValue (strategy = GenerationType.AUTO)
    private int id;

    private String name;

    @ManyToMany(cascade = CascadeType.PERSIST)
    private List<Course> courses;

    public void addCourse(Course course){
        courses.add(course);
        course.getTeachers().add(this);
    }

    public void removeCourse ( Course course){
        courses.remove(course);
        course.getTeachers().remove(this);
    }

    public Teacher() {
    }

    public Teacher(String name) {
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<Course> getCourses() {
        return courses;
    }

    public void setCourses(List<Course> courses) {
        this.courses = courses;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Teacher teacher = (Teacher) o;
        return id == teacher.id;
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }

    @Override
    public String toString() {
        return "         ID:" + Utility.fixString(10, String.valueOf(id))+
                "     " + Utility.fixString(15, String.valueOf(name));

    }


}

