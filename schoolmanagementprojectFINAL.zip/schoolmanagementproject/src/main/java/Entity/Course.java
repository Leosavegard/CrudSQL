package Entity;

import Management.Utility;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@Entity
public class Course {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int id;

    private String name;
    private int points;

    @ManyToMany(mappedBy = "courses", cascade = CascadeType.PERSIST)
    private List<Education> educationList = new ArrayList<>();

    @ManyToMany(mappedBy = "courses", cascade = CascadeType.PERSIST)
    private List<Teacher> teachers = new ArrayList<>();

    public Course(String name, int points) {
        this.name = name;
        this.points = points;
    }

    public Course() {
    }

    public void addTeacher(Teacher teacher) {
        teachers.add(teacher);
        teacher.getCourses().add(this);
    }

    public void removeTeacher(Teacher teacher) {
        teachers.remove(teacher);
        teacher.getCourses().remove(this);

    }

    public void addEducation(Education education) {
        educationList.add(education);
        education.getCourses().add(this);
    }

    public void removeEducation(Education education) {
        educationList.remove(education);
        education.getCourses().remove(this);
    }

    public List<Teacher> getTeachers() {
        return teachers;
    }

    public void setTeachers(List<Teacher> teachers) {
        this.teachers = teachers;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getPoints() {
        return points;
    }

    public void setPoints(int points) {
        this.points = points;
    }

    public List<Education> getEducationList() {
        return educationList;
    }

    public void setEducationList(List<Education> educationList) {
        this.educationList = educationList;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Course course = (Course) o;
        return id == course.id;
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }

    @Override
    public String toString() {
        return  "     ID:" + Utility.fixString(10, String.valueOf(id))+
                " " + Utility.fixString(15, String.valueOf(name))+
                "" + Utility.fixString(10, String.valueOf(points));
    }
}
