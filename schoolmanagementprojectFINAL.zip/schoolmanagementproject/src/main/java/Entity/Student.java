package Entity;

import Management.Utility;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@Entity
public class Student {
    @Id
    @GeneratedValue (strategy = GenerationType.AUTO)
    private int id;

    private String name;
    private int age;

    @ManyToMany(cascade = CascadeType.PERSIST, fetch = FetchType.LAZY)
    private List<Education> educationList = new ArrayList<>();

    public Student() {
    }

    public Student(String name, int age) {
        this.name = name;
        this.age = age;
    }

    public List<Education> getEducationList() {
        return educationList;
    }

    public void addEducation(Education education){
        educationList.add(education);
        education.getStudents().add(this);

    }

    public void removeEducation(Education education){
        educationList.remove(education);
        education.getStudents().remove(this);
    }

    public void setEducationList(List<Education> educationList) {
        this.educationList = educationList;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Student student = (Student) o;
        return id == student.id;
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }

    @Override
    public String toString() {
        return
                "     ID:" + Utility.fixString(10, String.valueOf(id))+
                 "Name:" + Utility.fixString(15, String.valueOf(name)) + "   " +
                "Age:" + Utility.fixString(10, String.valueOf(age));
    }
}
