package Entity;

import Management.Utility;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@Entity
public class
Education {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int id;

    private String name;
    private int length;

    @ManyToMany(mappedBy = "educationList",cascade = CascadeType.PERSIST, fetch = FetchType.LAZY)
    List<Student> students = new ArrayList<>();

    @ManyToMany (cascade = CascadeType.PERSIST)
    List<Course> courses = new ArrayList<>();

    public Education() {
    }

    public Education(String name, int length) {
        this.name = name;
        this.length = length;
    }

    public void addStudent(Student student) {
        students.add(student);
        student.getEducationList().add(this);
    }

    public void removeStudent(Student student) {
        students.remove(student);
        student.getEducationList().remove(this);
    }

    public void addCourse(Course course){
        courses.add(course);
        course.getEducationList().add(this);
    }

    public void removeCourse(Course course){
        courses.remove(course);
        course.getEducationList().remove(this);
    }

    public List<Course> getCourses() {
        return courses;
    }

    public void setCourses(List<Course> courses) {
        this.courses = courses;
    }

    public int getLength() {
        return length;
    }

    public void setLength(int length) {
        this.length = length;
    }

    public List<Student> getStudents() {
        return students;
    }

    public void setStudents(List<Student> students) {
        this.students = students;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getLenght() {
        return length;
    }

    public void setLenght(int length) {
        this.length = length;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Education education = (Education) o;
        return id == education.id && length == education.length && Objects.equals(name, education.name) && Objects.equals(students, education.students) && Objects.equals(courses, education.courses);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }

    @Override
    public String toString() {
        return  "      ID:" + Utility.fixString(10, String.valueOf(id))+
                "  " + Utility.fixString(15, String.valueOf(name))+
                Utility.fixString(10, String.valueOf(length) + " years");
    }
}
