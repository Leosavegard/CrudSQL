package Management;

import Entity.Education;
import Entity.Student;
import Interfaces.EducationDao;
import UI.EducationUI;


import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import java.util.List;

import static Main.MainProgram.*;


public class EducationManagement implements EducationDao {


    EntityManagerFactory emf = Persistence.createEntityManagerFactory("PU");

    public static void main(String[] args) {
        emgmt.removeEducationFromStudent();
    }


    @Override
    public Education createEducation() {

        System.out.println("Enter education name:");
        String name = Utility.readStringNameInput();


        System.out.println("Enter education length:");
        int length = Utility.readIntInput();

        return new Education(name, length);
    }

    @Override
    public void addEducation(Education education) {

        EntityManager em = emf.createEntityManager();

        em.getTransaction().begin();
        em.persist(education);
        em.getTransaction().commit();
        em.close();

        System.out.println("Education:" + education.getName() + " has been added to the database.");


    }

    @Override
    public void addEducationToExistingStudent(Education education) {

        boolean loop = true;

        while (loop) {


            EntityManager em = emf.createEntityManager();

            smgmt.showAllStudents();

            int id = Utility.askForID();

            Student student = em.find(Student.class, id);

            if (student == null) {
                System.out.println("No such id");
            } else {

                student.addEducation(education);

                em.getTransaction().begin();
                em.persist(student);
                em.getTransaction().commit();
                em.close();

                loop = false;

                System.out.println(education.getName() + " is now connected to the " + student.getName());

            }
        }

    }

    @Override
    public void removeEducation() {

        boolean loop = true;

        while (loop) {

            EntityManager em = emf.createEntityManager();

            showAllEducations();

            int id = Utility.readIntInput();

            Education education = em.find(Education.class, id);

            if (education == null) {
                System.out.println("Enter id to remove:");

            } else {

                em.getTransaction().begin();
                em.remove(education);
                em.getTransaction().commit();
                em.close();

                loop = false;

                System.out.println(education.getName() + " is now removed from the database.");
            }
        }
    }

    public void removeEducationFromStudent() {

        EntityManager em = emf.createEntityManager();

        smgmt.showAllStudents();

        int studentId = Utility.askForID();

        Student student = em.find(Student.class, studentId);

        List<Education> list = student.getEducationList();
        System.out.println("student " + student.getName() + " is connected to education ");
        list.forEach(education -> System.out.println(education.getName() + " "));
        Utility.pressAnyKeyToContinue();

        System.out.println("Please enter the id of the education you would like to remove from " + student.getName());

        showAllEducations();

        int educationId = Utility.askForID();

        Education education = em.find(Education.class, educationId);

        em.getTransaction().begin();
        student.removeEducation(education);
        em.getTransaction().commit();
        em.close();


    }

    @Override
    public void updateEducationName() {

        showAllEducations();

        EntityManager em = emf.createEntityManager();

        int id = Utility.askForID();

        Education e = em.find(Education.class, id);

        System.out.println("Enter new name: ");
        String name = Utility.readStringNameInput();


        em.getTransaction().begin();
        e.setName(name);
        em.getTransaction().commit();
        em.close();

        System.out.println("Education name with id:" + e.getId() + " has been updated .");


    }

    @Override
    public void updateEducationLength() {

        showAllEducations();
        EntityManager em = emf.createEntityManager();

        int id = Utility.askForID();

        Education e = em.find(Education.class, id);

        System.out.println("Enter new length:");
        int length = Utility.readIntInput();

        em.getTransaction().begin();
        e.setLength(length);
        em.getTransaction().commit();
        em.close();

        System.out.println("The length for education:" + e.getName() + " has been updated.");

    }

    @Override
    public void showEducation() {

        EntityManager em = emf.createEntityManager();


        int id = Utility.askForID();

        Education education = em.find(Education.class, id);

        List<Student> list = education.getStudents();

        System.out.println("Education " + education.getName() + " is attended by following students: ");
        list.forEach(student -> System.out.println(student.getName()));

    }

    @Override
    public void showAllEducations() {

        EntityManager em = emf.createEntityManager();

        EducationUI.showAllEducationHeader();

        em.createQuery("SELECT e FROM Education e", Education.class)
                .getResultStream()
                .forEach(System.out::println);

        EducationUI.showAllFooter();

        Utility.pressAnyKeyToContinue();
    }


}

