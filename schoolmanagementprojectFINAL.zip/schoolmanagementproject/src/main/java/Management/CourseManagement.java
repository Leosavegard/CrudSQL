package Management;

import Entity.Course;
import Entity.Education;
import Interfaces.CourseDao;
import UI.CourseUI;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import static Main.MainProgram.*;


public class CourseManagement implements CourseDao {


    EntityManagerFactory emf = Persistence.createEntityManagerFactory("PU");

    @Override
    public Course createCourse() {

        System.out.print("Course name:");
        String name = Utility.readStringNameInput();

        System.out.print("Points:");
        int points = Utility.readIntInput();

        return new Course(name, points);
    }

    @Override
    public void addCourse(Course course) {

        EntityManager em = emf.createEntityManager();

        em.getTransaction().begin();
        em.persist(course);
        em.getTransaction().commit();
        em.close();

        System.out.println("course " + course.getName() + " has been added.");


    }

    @Override
    public void addCourseToExistningEducation(Course course) {

        boolean loop = true;

        while (loop) {

            EntityManager em = emf.createEntityManager();

            emgmt.showAllEducations();

            int educationID = Utility.askForID();

            Education education = em.find(Education.class, educationID);

            if (education == null) System.out.println("No such id. Please try again");

            else {

                education.addCourse(course);
                em.getTransaction().begin();
                em.persist(education);
                em.getTransaction().commit();
                em.close();

                System.out.println("course: " + course.getName() + " has been connected to education:" + education.getName());

                loop = false;

            }

        }
    }

    @Override
    public void removeCourse() {

        boolean loop = true;

        while (loop) {

            EntityManager em = emf.createEntityManager();

            showAllCourses();

            int id = Utility.askForID();

            Course course = em.find(Course.class, id);

            if (course == null) System.out.println("No such id. Please try again");
            else {
                em.getTransaction().begin();
                em.remove(course);
                em.getTransaction().commit();
                em.close();

                System.out.println("course: " + course.getName() + " has been removed from the database.");
                loop = false;

            }


        }
    }

    @Override
    public void updateCourseName() {

        boolean loop = true;
        while (loop) {

            EntityManager em = emf.createEntityManager();

            showAllCourses();

            int id = Utility.askForID();

            Course course = em.find(Course.class, id);

            if (course == null) System.out.println("No such id. Please try again.");

            else {

                System.out.println("Enter new course name: ");
                String name = Utility.readStringNameInput();

                em.getTransaction().begin();
                course.setName(name);
                em.getTransaction().commit();
                em.close();

                System.out.println("The name for course with id:" + course.getId() + " has been updated");
                loop = false;

            }
        }
    }

    @Override
    public void updateCoursePoints() {

        boolean loop = true;
        while (loop) {

            EntityManager em = emf.createEntityManager();

            showAllCourses();

            int id = Utility.askForID();

            Course course = em.find(Course.class, id);

            if (course == null) System.out.println("No such id. Please try again.");

            else {

                System.out.println("Enter new amount of points:");
                int points = Utility.readIntInput();

                em.getTransaction().begin();
                course.setPoints(points);
                em.getTransaction().commit();
                em.close();

                System.out.println("The points for course:" + course.getName() + " has been updated");
                loop = false;

            }
        }
    }

    @Override
    public void showCourse() {

        boolean loop = true;
        while (loop) {

            EntityManager em = emf.createEntityManager();

            int id = Utility.askForID();

            Course course = em.find(Course.class, id);
            if (course == null) System.out.println("No such id. Please try again.");

            else {
                System.out.println(course);
                loop = false;
            }


        }
    }

    @Override
    public void showAllCourses() {

        EntityManager em = emf.createEntityManager();

        CourseUI.showAllCoursesHeader();

        em.createQuery("SELECT c FROM Course c", Course.class)
                .getResultStream()
                .forEach(System.out::println);

       CourseUI.showAllFooter();

       Utility.pressAnyKeyToContinue();
    }

    @Override
    public void connectCourseWithEducation() {

        EntityManager em = emf.createEntityManager();

        Course course;
        Education education;

        while (true) {

            showAllCourses();

            int courseId = Utility.askForID();

            course = em.find(Course.class, courseId);

            if (course == null) {
                System.out.println("No such id. Please try again");

            } else break;

        }

        while (true) {

            emgmt.showAllEducations();
            int idCourse = Utility.askForID();
            education = em.find(Education.class, idCourse);

            if (education == null) {
                System.out.println("No such id. Please try again");
            } else break;

        }

        if (!education.getCourses().contains(course)) {

            em.getTransaction().begin();
            education.addCourse(course);
            em.getTransaction().commit();
            em.close();

            System.out.println("Course:" + course.getName() + " is now connected to education: " + education.getName());

        } else System.out.println(course.getName() + " Is already connected with education:" + education.getName());
    }
}
