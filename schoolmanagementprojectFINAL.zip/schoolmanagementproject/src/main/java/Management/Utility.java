package Management;

import java.util.Scanner;

public class Utility {
    static Scanner sc = new Scanner(System.in);


    public static String readStringNameInput() {

        String name;

        while (true) {

            try {
                name = sc.nextLine();
                break;
            } catch (Exception e) {
                System.out.println("Enter text only");
            }
        }
        return name;

    }

    public Double readDoubleInput() {

        Double input;

        while (true) {

            try {
                input = sc.nextDouble();
                sc.nextLine();
                break;
            } catch (Exception e) {
                System.out.println("Enter Numbers only. Example: 00,00");
                sc.nextLine();
            }
        }
        return input;

    }

    public static int readIntInput() {

        int i;

        while (true) {

            try {
                i = sc.nextInt();
                sc.nextLine();
                break;
            } catch (Exception e) {
                System.out.println("Enter Numbers only. Example: 00.00");
                sc.nextLine();
            }
        }
        return i;

    }

    public static int askForID() {
        System.out.println("Enter id:");

        return readIntInput();
    }

    public static void pressAnyKeyToContinue() {
        System.out.println("\nPress any key to continue:");
        sc.nextLine();
    }

    public static void noSuchOptionText() {

        System.out.println("No such option, try again.");
    }

    public static String fixString(int wantedSize, String stringToFix) {

        if (stringToFix.length() < wantedSize) {

            while (stringToFix.length() < wantedSize) {

                stringToFix = stringToFix + " ";
            }

            return stringToFix + "   ";
        } else
            return stringToFix.substring(0, wantedSize) + "   ";
    }


}
