package Management;

import Entity.Education;
import Entity.Student;
import Entity.Teacher;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import java.text.DecimalFormat;
import java.util.DoubleSummaryStatistics;
import java.util.IntSummaryStatistics;

public class StatisticManagement {

    static DecimalFormat df = new DecimalFormat("#.##");


    EntityManagerFactory emf = Persistence.createEntityManagerFactory("PU");


    public void averageAgeStudents() {

        EntityManager em = emf.createEntityManager();

        DoubleSummaryStatistics stat = em.createQuery("SELECT s  FROM Student s", Student.class).getResultStream().mapToDouble(Student::getAge).summaryStatistics();

        System.out.println("Average age is " + df.format(stat.getAverage()));

        Utility.pressAnyKeyToContinue();
    }

    public void maxAndMinAgeStudent() {

        EntityManager em = emf.createEntityManager();

        IntSummaryStatistics stat = em.createQuery("SELECT s FROM Student  s", Student.class).getResultStream().mapToInt(Student::getAge).summaryStatistics();

        System.out.println("Oldest student: " + stat.getMax() + "\nYoungest student: " + stat.getMin());

        Utility.pressAnyKeyToContinue();
    }


    public void numberOfTeachers() {

        EntityManager em = emf.createEntityManager();

        IntSummaryStatistics stat = em.createQuery("SELECT t FROM Teacher t", Teacher.class).getResultStream().mapToInt(Teacher::getId).summaryStatistics();

        int count = (int) stat.getCount();

        System.out.println("Number of teachers are: " + count);

        Utility.pressAnyKeyToContinue();


    }

    public void averageEducationLength() {

        EntityManager em = emf.createEntityManager();

        DoubleSummaryStatistics stat = em.createQuery("SELECT e FROM Education e", Education.class).getResultStream().mapToDouble(Education::getLength).summaryStatistics();

        System.out.println("Average education length is: " + df.format(stat.getAverage()) + " years");

        Utility.pressAnyKeyToContinue();


    }

    public void maxAndMinEducationLength() {

        EntityManager em = emf.createEntityManager();

        IntSummaryStatistics stat = em.createQuery("SELECT e FROM Education e", Education.class).getResultStream().mapToInt(Education::getLength).summaryStatistics();

        System.out.println("The longest education is: " + stat.getMax() + " years" + "\nThe shortest education is: " + stat.getMin() + " years");

        Utility.pressAnyKeyToContinue();

    }
}





