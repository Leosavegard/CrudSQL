package Management;

import Entity.Education;
import Entity.Student;
import Interfaces.StudentDao;
import UI.StudentUI;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.swing.text.html.parser.Entity;

import java.util.List;

import static Main.MainProgram.*;

public class StudentManagement implements StudentDao {

    EntityManagerFactory emf = Persistence.createEntityManagerFactory("PU");


    @Override
    public Student createStudent() {

        System.out.print("Student name:");
        String name = Utility.readStringNameInput();

        System.out.print("Age:");
        int age = Utility.readIntInput();

        return new Student(name, age);
    }

    @Override
    public void addStudent(Student student) {

        EntityManager em = emf.createEntityManager();


        em.getTransaction().begin();
        em.persist(student);
        em.getTransaction().commit();
        em.close();

        System.out.println("Student:" + student.getName() + " has been added to the database.");


    }

    @Override
    public void addStudentToExistingEducation(Student student) {

        boolean loop = true;

        while (loop) {

            emgmt.showAllEducations();
            EntityManager em = emf.createEntityManager();

            int educationId = Utility.askForID();

            Education education = em.find(Education.class, educationId);


            if (education == null) {
                System.out.println("No such id. Please try again.");
            } else {

                education.addStudent(student);

                em.getTransaction().begin();
                em.persist(education);
                em.getTransaction().commit();
                em.close();

                loop = false;
            }
        }

        System.out.println("Student:" + student.getName() + " has been added to education " + "");

    }

    @Override
    public void removeStudent() {

        boolean loop = true;

        while (loop) {

            showAllStudents();
            EntityManager em = emf.createEntityManager();

            int id = Utility.askForID();

            Student student = em.find(Student.class, id);

            if (student == null) {
                System.out.println("No such id. Please try again.");
            } else {

                em.getTransaction().begin();
                em.remove(student);
                em.getTransaction().commit();
                em.close();
                loop = false;
            }

        }

    }

    public void removeStudentFromEducation() {

        EntityManager em = emf.createEntityManager();

        emgmt.showAllEducations();
        int educationID = Utility.askForID();

        Education education = em.find(Education.class, educationID);

        List<Student> list = education.getStudents();
        System.out.println("Education " + education.getName() + " is connected to student ");
        list.forEach(student -> System.out.println(student.getName() + " "));
        Utility.pressAnyKeyToContinue();

        System.out.println("Please enter the id of the student you would like to remove from " + education.getName());

        showAllStudents();

        int educationId = Utility.askForID();

        Student student = em.find(Student.class, educationId);

        em.getTransaction().begin();
        education.removeStudent(student);
        em.getTransaction().commit();
        em.close();


    }

    @Override
    public void updateStudentName() {

        boolean loop = true;

        while (loop) {

            showAllStudents();
            EntityManager em = emf.createEntityManager();

            int id = Utility.askForID();

            Student student = em.find(Student.class, id);

            if (student == null) {
                System.out.println("No such id. please try again.");
            } else {

                System.out.println("Enter new name: ");
                String name = Utility.readStringNameInput();


                em.getTransaction().begin();
                student.setName(name);
                em.getTransaction().commit();
                em.close();

                loop = false;

            }
        }
    }

    @Override
    public void updateStudentAge() {

        boolean loop = true;

        while (loop) {

            showAllStudents();
            EntityManager em = emf.createEntityManager();

            int id = Utility.askForID();

            Student student = em.find(Student.class, id);

            if (student == null) {
                System.out.println("No such id. Please try again.");
            } else {

                System.out.println("Enter new age:");
                int age = Utility.readIntInput();

                em.getTransaction().begin();
                student.setAge(age);
                em.getTransaction().commit();
                em.close();
                loop = false;
            }


        }
    }

    @Override
    public void showStudent() {

        boolean loop = true;

        while (loop) {

            EntityManager em = emf.createEntityManager();

            showAllStudents();

            int id = Utility.askForID();

            Student student = em.find(Student.class, id);


            if (student == null) System.out.println("No such id. Please try again.");

            else {
                List<Education> list = student.getEducationList();
                System.out.print("student " + student.getName() + " is connected to education ");
                list.forEach(education -> System.out.println(education.getName() + " "));
                loop = false;
            }
        }
    }

    @Override
    public void showAllStudents() {

        EntityManager em = emf.createEntityManager();

        StudentUI.showAllStudentHeader();
        em.createQuery("SELECT s FROM Student s", Student.class)
                .getResultStream()
                .forEach(System.out::println);

        StudentUI.showAllFooter();

        Utility.pressAnyKeyToContinue();

    }

    @Override
    public void connectStudentWithEducation() {

        EntityManager em = emf.createEntityManager();

        Education education;
        Student student;

        while (true) {

            emgmt.showAllEducations();

            int idEducation = Utility.askForID();

            education = em.find(Education.class, idEducation);

            if (education == null) System.out.println("no such id. Please try again.");
            else break;

        }

        while (true) {

            showAllStudents();
            int idStudent = Utility.askForID();
            student = em.find(Student.class, idStudent);

            if (student == null) System.out.println("No such id. Please try again");
            else break;
        }

        if (!student.getEducationList().contains(education)) {
            em.getTransaction().begin();
            student.addEducation(education);
            em.getTransaction().commit();
            em.close();

            System.out.println(student.getName() + " is now connected with education :" + education.getName());

        } else
            System.out.println(student.getName() + " is already connected with education :" + education.getName());


    }


}

