package Management;

import Entity.Course;
import Entity.Teacher;
import Interfaces.TeacherDao;
import UI.TeacherUI;


import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;


import static Main.MainProgram.*;

public class TeacherManagement implements TeacherDao {

    EntityManagerFactory emf = Persistence.createEntityManagerFactory("PU");


    @Override
    public Teacher createTeacher() {

        System.out.print("Teacher name:");
        String name = Utility.readStringNameInput();

        return new Teacher(name);
    }

    @Override
    public void addTeacher(Teacher teacher) {

        EntityManager em = emf.createEntityManager();

        em.getTransaction().begin();
        em.persist(teacher);
        em.getTransaction().commit();
        em.close();

        System.out.println(teacher.getName() + " is now added to the database.");

    }

    @Override
    public void addTeacherToExistingCourse(Teacher teacher) {

        boolean loop = true;

        while (loop) {

            EntityManager em = emf.createEntityManager();

            cmgmt.showAllCourses();

            int courseId = Utility.askForID();

            Course course = em.find(Course.class, courseId);

            if (course == null) {
                System.out.println("No such id");
            } else {

                course.addTeacher(teacher);

                em.getTransaction().begin();
                em.persist(course);
                em.getTransaction().commit();
                em.close();

                loop = false;

                System.out.println(teacher.getName() + " is now connected to the " + course.getName());
            }
        }
    }

    @Override
    public void removeTeacher() {

        boolean loop = true;

        while (loop) {

            EntityManager em = emf.createEntityManager();

            showAllTeachers();

            int id = Utility.askForID();

            Teacher teacher = em.find(Teacher.class, id);


            if (teacher == null) {
                System.out.println("No such id, Please try again");
            } else {

                em.getTransaction().begin();
                em.remove(teacher);
                em.getTransaction().commit();
                em.close();

                loop = false;

                System.out.println(teacher.getName() + " is now removed from the database.");
            }
        }
    }

    @Override
    public void updateTeacherName() {

        boolean loop = true;

        while (loop) {

            EntityManager em = emf.createEntityManager();

            showTeacher();

            int id = Utility.askForID();

            Teacher teacher = em.find(Teacher.class, id);

            if (teacher == null) {
                System.out.println("No such id, Please try again");
            } else {

                System.out.println("Enter new name: ");
                String name = Utility.readStringNameInput();


                em.getTransaction().begin();
                teacher.setName(name);
                em.getTransaction().commit();
                em.close();

                loop = false;

                System.out.println("Name of teacher with id: " +  teacher.getId() + " is now updated");
            }

        }
    }

    @Override
    public void showTeacher() {

        boolean loop = true;

        while (loop) {


            EntityManager em = emf.createEntityManager();

            int id = Utility.askForID();

            Teacher teacher = em.find(Teacher.class, id);

            if (teacher == null) {
                System.out.println("No such id. Please try again");
            } else {

                System.out.println(teacher);

                Utility.pressAnyKeyToContinue();
                loop = false;
            }
        }
    }


    @Override
    public void showAllTeachers() {

        EntityManager em = emf.createEntityManager();

        TeacherUI.showAllTeacherHeader();

        em.createQuery("SELECT t FROM Teacher t", Teacher.class)
                .getResultStream()
                .forEach(System.out::println);

        TeacherUI.showAllteacherFooter();

        Utility.pressAnyKeyToContinue();
    }

    @Override
    public void connectTeacherWithCourse() {
        EntityManager em = emf.createEntityManager();

        Teacher teacher;
        Course course;

        while (true) {
            showAllTeachers();

            int idTeacher = Utility.askForID();

            teacher = em.find(Teacher.class, idTeacher);

            if (teacher == null) {
                System.out.println("No such id. Please try again.");


            } else break;
        }


        while (true) {

            cmgmt.showAllCourses();
            int idCourse = Utility.askForID();
            course = em.find(Course.class, idCourse);


            if (course == null) {
                System.out.println("No such id. Please try again.");
            } else break;

        }

        if (!teacher.getCourses().contains(course)) {
            em.getTransaction().begin();
            teacher.addCourse(course);
            em.getTransaction().commit();
            em.close();

            System.out.println(teacher.getName() + " is now connected with course: " + course.getName());


        } else System.out.println(teacher.getName() + " is already connected with course: " + course.getName());




    }


}



