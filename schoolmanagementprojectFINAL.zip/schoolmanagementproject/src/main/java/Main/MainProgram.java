package Main;

import Management.*;
import MenuSwitches.MainSwitch;


public class MainProgram {

    public static StudentManagement smgmt = new StudentManagement();
    public static EducationManagement emgmt = new EducationManagement();
    public static TeacherManagement tmgmt = new TeacherManagement();
    public static CourseManagement cmgmt = new CourseManagement();
    public static StatisticManagement statgmt = new StatisticManagement();


    public static void main(String[] args) {

        MainSwitch ms = new MainSwitch();

            ms.runProgram();

    }
}